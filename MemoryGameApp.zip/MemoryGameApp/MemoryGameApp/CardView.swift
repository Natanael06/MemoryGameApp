//
//  CardView.swift
//  MemoryGameApp
//
//  Created by NATANAEL  MEDINA  on 3/11/25.
//

import SwiftUI

struct CardView: View {
    
    let card: Card
    // card state
    var isFaceDown: Bool
    
    var body: some View {
        
        ZStack{
            // Card Background
            RoundedRectangle(cornerRadius: 15.0)
                .fill(isFaceDown ? Color.blue : Color.white)
                .frame(width: 105.0, height: 175.0)
                .overlay( RoundedRectangle(cornerRadius: 15.00)
                    .stroke(isFaceDown ? Color.blue : Color.black, lineWidth: isFaceDown ? 1 : 5)
                )
            
            if !isFaceDown {
                        card.icon
                                .resizable()
                                .scaledToFit()
                                .frame(width: 60, height: 60)
                                .foregroundColor(.black)
                        }
        }
        .animation(.easeInOut, value: isFaceDown)
    }
}

struct Card{
    let icon: Image
    
    static let icons = [
        Card(icon: Image(systemName: "globe")),
        Card(icon: Image(systemName: "star.fill")),
        Card(icon: Image(systemName: "heart.fill")),
        Card(icon: Image(systemName: "bell.fill")),
        Card(icon: Image(systemName: "paperplane.fill")),
        Card(icon: Image(systemName: "house.fill")),
        Card(icon: Image(systemName: "gearshape.fill")),
        Card(icon: Image(systemName: "person.fill")),
        Card(icon: Image(systemName: "sun.max.fill")),
        Card(icon: Image(systemName: "moon.fill"))
    ]
}

#Preview {
    CardView(card: Card(icon: Image(systemName: "moon.fill")), isFaceDown: true)
}
