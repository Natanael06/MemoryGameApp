//
//  ContentView.swift
//  MemoryGameApp
//
//  Created by NATANAEL  MEDINA  on 3/11/25.
//

import SwiftUI

struct ContentView: View {
    
    @State private var cards: [Card] = []
    @State private var selectedCards: [Int] = []
    @State private var matchedCards: Set<Int> = []
    
    // Bind the Picker selection to this state variable.
    @State private var numOfPairs: Int = 2 // Default value
    
    // Options available in the picker.
    let pairOptions = [2, 4, 6, 8, 10]
    
    let columns = [
        GridItem(.flexible()),
        GridItem(.flexible()),
        GridItem(.flexible()),
    ]
    
    var body: some View {
        VStack() {
            // Heading buttons
            HStack{
                // Chose size button
                Menu {
                    ForEach(pairOptions, id: \.self) { value in
                        Button(action: {
                            numOfPairs = value
                        }) {
                            Text("\(value) pairs")
                        }
                    }
                } label: {
                    Text("Choose Size")
                        .foregroundColor(.white)
                        .font(.headline)
                       
                }.frame(width: 125, height: 55)
                .background(Color.orange)
                .cornerRadius(35)
                
                // Reset buttom
                Button(action: setupGame) {
                    Text("Reset")
                        .foregroundColor(.white)
                        .font(.headline)
                }
                .frame(width: 125, height: 55)
                .background(Color.green)
                .cornerRadius(35)

            }
            //Cards Grid
            ScrollView{
                LazyVGrid(columns: columns, spacing: 12) {
                    ForEach(cards.indices, id: \.self) { index in
                        CardView(
                            card: cards[index],
                            isFaceDown: !matchedCards.contains(index) && !selectedCards.contains(index)
                        )
                        .opacity(matchedCards.contains(index) ? 0 : 1)
                        .onTapGesture {
                            handleCardTap(index)
                        }
                    }
                    
                }.padding()
            }
            .padding()
            .onAppear(perform: setupGame)
            // Reset game whenever the number of pairs changes.
            .onChange(of: numOfPairs) {
                setupGame()
            }
        }
    }
    
    func handleCardTap(_ index: Int) {
        guard !matchedCards.contains(index), !selectedCards.contains(index) else { return }
        
        selectedCards.append(index)
        
        if selectedCards.count == 2 {
            let firstIndex = selectedCards[0]
            let secondIndex = selectedCards[1]
            
            if cards[firstIndex].icon == cards[secondIndex].icon {
                // If matched, add to matchedCards set
                matchedCards.insert(firstIndex)
                matchedCards.insert(secondIndex)
            } else {
                // If not matched, flip back after a short delay
                DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                    selectedCards.removeAll()
                }
            }
        } else if selectedCards.count > 2 {
            selectedCards.removeAll()
        }
    }
    func setupGame() {
        var tempCards: [Card] = []
        // Create pairs using available icons.
        for i in 0..<numOfPairs {
            tempCards.append(Card.icons[i])
            tempCards.append(Card.icons[i])
        }
        tempCards.shuffle()
        cards = tempCards
        selectedCards.removeAll()
        matchedCards.removeAll()
    }
    
}
#Preview {
    ContentView()
}
